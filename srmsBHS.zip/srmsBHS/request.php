<!DOCTYPE html>
<html>
<head>
    <title>Request Form</title>
</head>
<body>

<?php
    // Database connection configuration
    $servername = "localhost";
    $username = "root"; // Your MySQL username
    $password = ""; // Your MySQL password
    $dbname = "dbgrading"; // Your database name

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Check if the form is submitted
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // $student_id = $_POST['student_id'];
        $purpose = $_POST['purpose'];
        $contact = $_POST['contact'];
        $request_type = $_POST['request_type'];

        // Insert the data into the database
        $sql = "INSERT INTO tblrequest (SID,purpose, contact, request_type) VALUES ('".$_SESSION['IDNO']."','$purpose', '$contact', '$request_type')";

        if ($conn->query($sql) === TRUE) {
            echo "Request submitted successfully";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
?>

<div class="container py-5 mt-5 ">
    <div class="row">
        <div class="card mt-5 col-sm-6">
            <div class="card-body">
                <form class="mt-5 pt-5" method="POST">
                    <div class="form-row">
                        <div class="form-group col-md-8">
                        <label for="inputCity">Contact Number</label>
                        <input type="text" name="contact" class="form-control" id="inputCity" placeholder="Contact Number">
                        </div>
                        <div class="form-group col-md-4">
                        <label for="inputState">Type of Request</label>
                        <select id="inputState" name="request_type" class="form-control">
                            <option selected>Choose...</option>
                            <option>SF9/Form 138</option>
                            <option>SF10/Form 137</option>
                        </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="inputAddress2">Purpose</label>
                        <input type="text" name="purpose"class="form-control" id="inputAddress2" placeholder="What is your ">
                    </div>
                    <!-- <div class="form-group">
                        <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="gridCheck">
                        <label class="form-check-label" for="gridCheck">
                            Check me out
                        </label>
                        </div>
                    </div> -->
                    <button type="submit" class="btn btn-primary">Send Request</button>
                </form>
            </div>
        </div>
        <div class="card mt-5 col-sm-6">
            <div class="">
            <div class="landing-page shadow-sm bg-success" style="background: url(admin/cover.jpg) center no-repeat;">
                    <!-- <a class="position-absolute btn-sm btn btn-outline-light m-4 zindex" href="home.html">Skip <i class="icofont-bubble-right"></i></a>  -->
                    <div class="osahan-slider m-0">
                        <div class="osahan-slider-item text-center">
                        <div class="d-flex align-items-center justify-content-center vh-100 flex-column">
                        <i class="icofont-sale-discount display-1 text-warning"></i>
                        <img src="assets/img/beguin.png" class="display-1" width="30%" alt="">
                        <h4 class="my-4 text-white">Beguin National High School</h4>
                        <p class="text-center text-white-50 mb-5 px-4">Cheaper prices than your local<br>supermarket, great cashback offers to top it off.</p>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
