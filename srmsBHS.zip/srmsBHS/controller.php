<?php 
require_once ("includes/initialize.php");
$action = (isset($_GET['action']) && $_GET['action'] != '') ? $_GET['action'] : '';

switch ($action) {
	case 'request' :
	doInsert();
	break;
	
	case 'edit' :
	doEdit();
	break;
	
	case 'delete' :
	doDelete();
	break;
	case 'updatetime' :
	doupdatetime();
	break;


}

function doupdatetime(){
	if (isset($_POST['saverequest'])){
	

	if ($_POST['subjcode'] == "" OR $_POST['subjdesc'] == "" OR $_POST['unit'] == "") {
		message("All field is required!","error");
		redirect('index.php');
	}else{
		

		$instClass = new InstructorClasses();
		$Subjectid		= $_GET['id'];
		$subjcode   	= $_POST['subjcode'];
		$day 			= $_POST['day'];
		//$rm 			= $_POST['rmname'];
		$time 			= $_POST['time'];
		$ay 			= $_POST['sy'];
		


			// $instClass->SUBJ_ID			 = $Subjectid;
			// $instClass->CLASS_CODE		 = $subjcode;
			// $instClass->INST_ID 		 = $INST_ID;		
			$instClass->ROOM 			 = $_POST['rmname'];
			$instClass->SECTION 		 = $_POST['section'];
			$instClass->DAY 		 	 = $day;
			$instClass->C_TIME 		 	 = $time;
 			$instClass->update($_GET['classId']);
			message($subjcode. " has updated successfully!", "info");
			redirect('index.php');
			 
			
		}	 

		
	}
}

function doInsert(){
		
	if (isset($_POST['request'])){

	if ($_POST['contact'] == "" OR $_POST['request_type'] == "") {
		message("All field is required!","error");
		check_message();
	}else{
		

		$request = new Request();
		$contact   	= $_POST['contact'];
		$request_type   	= $_POST['request_type'];
		// $requestmajor   	= $_POST['major'];
		// $requestdesc 	= $_POST['requestdesc'];
		// $requestdept		= $_POST['dept'];
		$res = $request->find_all_request($requestname, $requestlevel, $requestmajor);
				
		if ($res >=1) {
			message("request name already exist!","error");
			check_message();
		}else{
			$request->request_NAME = $requestname;
			$request->request_LEVEL = $requestlevel;
			$request->request_MAJOR = $requestmajor;
			$request->request_DESC = $requestdesc;
			$request->DEPT_ID = $requestdept;	
			 $istrue = $request->create(); 
			 if ($istrue == 1){
			 	
			 	message("New [". $requestname ."] request created successfully!","success");
			 	redirect('index.php');
			 }
		}	 

		
	}
}
}
function doEdit(){
	$requestid = $_GET['id'];
	$singledept = new request();
	$object = $singledept->single_request($requestid);


	if (isset($_POST['saverequest'])){

		if ($_POST['requestname'] == "" OR $_POST['requestdesc'] == "") {
			
			message("All field is required!", "error");

		}else{
			$request = new request();
			$requestid		= $_GET['id'];
			$requestname   	= $_POST['requestname'];
			$requestlevel   	= $_POST['level'];
			$requestmajor   	= $_POST['major'];
			$requestdesc 	= $_POST['requestdesc'];
			$requestdept		= $_POST['dept'];
					
			$request->request_NAME = $requestname;
			$request->request_LEVEL = $requestlevel;
			$request->request_MAJOR = $requestmajor;
			$request->request_DESC = $requestdesc;
			$request->DEPT_ID 	 = $requestdept;	
			$request->update($requestid);
			

			message($requestname. " has updated successfully!", "info");
			redirect('index.php');

		}
	}
		
}

function doDelete(){
	  @$id=$_POST['selector'];
	  $key = count($id);
	//multi delete using checkbox as a selector
	
	for($i=0;$i<$key;$i++){
 
		$request = new request();
		$request->delete($id[$i]);
	}
	message("request(s) already Deleted!","info");
	redirect('index.php');
}
?>