<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-dfe5dST9a3v9aMZZ2u8egLh1gO5X1WagR5gZ9vgcSHvUU5mzDbefO6n1CjDFQ+Pr" crossorigin="anonymous">
  <title>Student Report Card</title>
</head>
<body>

  <div class="container mt-5">
    <div class="row">
      <div class="col-6">
        <img src="logo1.png" alt="Logo 1" class="img-fluid">
      </div>
      <div class="col-6 text-end">
        <img src="logo2.png" alt="Logo 2" class="img-fluid">
      </div>
    </div>
    
    <div class="row mt-3">
      <div class="col-12 text-center">
        <h1>School Name</h1>
      </div>
    </div>

    <div class="row mt-4">
      <div class="col-12">
        <table class="table">
          <thead>
            <tr>
              <th scope="col">Subject</th>
              <th scope="col">Marks</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Mathematics</td>
              <td>85</td>
            </tr>
            <tr>
              <td>Science</td>
              <td>90</td>
            </tr>
            <tr>
              <td>English</td>
              <td>80</td>
            </tr>
            <!-- Add more subjects as needed -->
          </tbody>
        </table>
      </div>
    </div>

    <div class="row mt-4">
      <div class="col-12">
        <p><strong>Total Marks:</strong> 255</p>
        <p><strong>Percentage:</strong> 85%</p>
        <p><strong>Grade:</strong> A</p>
      </div>
    </div>

  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-o3udJJdQQMGmu1JiZNBR4LlcczReQd83rGHW1IJgNZnFUOx+2Eh8q5gCS+BXE2sY" crossorigin="anonymous"></script>
</body>
</html>
