<?php
include 'config.php';
$id = $_GET['id'];
$status = $_GET['status'];
$query = "UPDATE tblrequest SET status = $status WHERE id = $id";
$result = mysqli_query($conn, $query);
if ($result) {
    header('location:index.php');
} else {
    header('location:index.php');
}
?>