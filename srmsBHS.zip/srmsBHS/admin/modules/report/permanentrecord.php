<style type="text/css">
  .row {
    margin-bottom: 5px;
  }
  #table {
  	width: 100%;
  }
  #table tr td,
   #table tr th  {
  	padding: 0px;
  	margin: 0px;
  }

  #table tr th {
  	border-bottom: 1px solid #ddd;
  	white-space: nowrap;
  }
   
  @media print {
  	 #table tr th {
  	border-bottom: 1px solid #ddd;
  	white-space: nowrap;
  }
  }
  @media print
{    
    .no-print, .no-print *
    {
        display: none !important;
    }
}
</style>
<div class="rows">
<a href="index.php" name="back" class="btn btn-default"></span>Back</a>
	
	<div class="col-sm-12">
		  <!-- =============================================== -->
<form class="" method="POST" action=""> 
	<div class="row no-print">
					 <div class="row">
					  <div class="col-sm-12 search1">
					    <label class="col-sm-12 ">Student Name:</label>
					    <div class="col-sm-12 ">
					      <div class="input-group date">
					        <div class="input-group-addon">
					          <i class="glyphicon glyphicon-user"></i>
					        </div>
					        <input required  type="text" value="<?php echo isset($_POST['studentname']) ? $_POST['studentname'] : ""; ?>" name="studentname" class="form-control pull-right date_picker "  id="studentname" placeholder="ID Number">
					      </div>
					    </div>
					  </div>
					</div>   
					 <div class="row">
					  <div class="col-sm-12 search1">
					    <label class="col-sm-12">Academic Year:</label>
					    <div class="col-sm-12"> 
					    	  <select class="form-control input-sm" name="ay" id="ay">
									<option value="2018-2019">2018-2019</option>
									<option value="2019-2020">2020-2021</option>	
									<option value="2022-2023">2022-2023</option>	
									<option value="2023-2024">2023-2024</option>	
									<option value="2024-2025">2024-2025</option>	
									<option value="2025-2026">2025-2026</option>	
									<option value="2026-2027">2026-2027</option>	
								</select>	
					    </div>
					  </div>
					</div>    
					<div class="row">
					  <div class="col-sm-6 search1">
					    <label class="col-sm-3"></label>
					    <div class="col-sm-9">
					       <input type="submit" name="submit" class="btn btn-success pull-center">
					    </div>
					  </div>
					</div>  
				</div> 
</form>


  <section class="content"> 
  	<div class="col-md-4">
  		<img src="<?php echo WEB_ROOT;?>img/deped2.png">
  	</div>
  	<div class="col-md-4">
  		
		  	<p style="text-align: center;font-size: 15px;padding: 0px;margin: 0px;"> 
			Republic of the Philippines <br/> 
			Department of Education <br/>
			<h2 style="text-align: center;padding: 0px;margin: 0px;">Learner Permanent Record for Junior High School (SF10-JHS)</h2> 
		 	</p>
  	</div>
  	<div class="col-md-4"> 
  		<img src="<?php echo WEB_ROOT;?>img/Logo-DepEd-1.png">
  	</div>

<br/>
<table id="table">

  <thead>
  	<tr>
		<th style="text-align: center;border-top: 1px solid #ddd;background-color: #ddd" colspan="9">LEARNER'S INFORMATION</th>   
  	</tr>	
  </thead> 
  <tbody>
  	<?php     
  		$studentname = isset($_POST['studentname']) ? $_POST['studentname'] : '' ;
  		$ay = isset($_POST['ay']) ? $_POST['ay'] : '' ;
  		$sql ="SELECT * FROM `schoolyr` ac, `tblstudent` s WHERE s.`IDNO`=ac.`IDNO` AND s.`IDNO`='{$studentname}' AND AY = '{$ay}' GROUP BY s.IDNO LIMIT 1";

  		$mydb->setQuery($sql);
  		$cur = $mydb->loadResultList();

		foreach ($cur as $result) { 
	  		echo '<tr>'; 
	  		echo '<td>FIRSTNAME:</td>';
	  		echo '<th>'. $result->FNAME.'</th>';  
	  		echo '<td>LASTNAME:</td>';
	  		echo '<th>' . $result->LNAME.'</th>';
	  		echo '<td>NAME EXTN(JR I, II):</td>'; 
	  		echo '<td></td>'; 
	  		echo '<td>MIDDLENAME:</td>'; 
	  		echo '<th>'. $result->MNAME.'</th>';   
	  		echo '</tr>';

	  		echo '<tr>'; 
	  		echo '<td colspan="2">Learner Reference Number (LRN):</td>';
	  		echo '<th>'. $result->IDNO.'</th>';  
	  		echo '<td>Birthdate(mm/dd/yyyy):</td>';
	  		echo '<th>' . date_format(date_create($result->BDAY),"m/d/Y").'</th>'; 
	  		echo '<td>Sex :</td>'; 
	  		echo '<th>'. $result->SEX.'</th>';   
	  		echo '</tr>';
  		} 
  	?>
  </tbody> 
</table>
<br/>
<table id="table">

  <thead>
  	<tr>
		<th style="text-align: center;border-top: 1px solid #ddd;background-color: #ddd" colspan="9"><h6></h6></th>   
  	</tr>	
  </thead> 
  <tbody>
  	<?php     
  		$sql ="SELECT * FROM `schoolyr` ac, `tblstudent` s , `grades` g WHERE ac.`IDNO`=s.`IDNO` and s.`IDNO`=g.`IDNO` AND s.`IDNO`='{$studentname}' AND AY = '{$ay}' GROUP BY s.IDNO LIMIT 1";

  		$mydb->setQuery($sql);
  		$cur = $mydb->loadResultList();

		foreach ($cur as $result) { 
	  		echo '<tr>'; 
	  		echo '<td>Elementary School Completer:</td>';
	  		echo '<th>'. $result->FNAME.'</th>';  
	  		echo '<td>General Average::</td>';
	  		echo '<th>' . $result->LNAME.'</th>';
	  		echo '<td>Citation: (If Any):</td>'; 
	  		echo '<td></td>';  
	  		echo '</tr>';

	  		echo '<tr>'; 
	  		echo '<td >Name of Elementary School:</td>';
	  		echo '<th>'. $result->IDNO.'</th>';  
	  		echo '<td>School ID:</td>';
	  		echo '<th>' . date_format(date_create($result->BDAY),"m/d/Y").'</th>'; 
	  		echo '<td>Adress of School:</td>'; 
	  		echo '<th>'. $result->SEX.'</th>';   
	  		echo '</tr>';
  		} 
  	?>
  </tbody> 
</table>

<br/>
<table id="table">

  <thead>
  	<tr>
		<th style="text-align: center;border-top: 1px solid #ddd;background-color: #ddd" colspan="10">SCHOLASTIC RECORD</th>   
  	</tr>	
  </thead> 
  <tbody>
  	<?php     
  		$sql ="SELECT * FROM `tblstudent` s, `class` c WHERE s.`IDNO`=c.`IDNO`  AND s.`IDNO`='{$studentname}' AND AY = '{$ay}' GROUP BY s.IDNO LIMIT 1";

  		$mydb->setQuery($sql);
  		$cur = $mydb->loadResultList();

		foreach ($cur as $result) { 
	  		echo '<tr>'; 
	  		echo '<td>School:</td>';
	  		echo '<th>'. $result->FNAME.'</th>';  
	  		echo '<td>School ID:</td>';
	  		echo '<th>' . $result->LNAME.'</th>';
	  		echo '<td>District:</td>'; 
	  		echo '<td></td>';  
	  		echo '<td>Division:</td>'; 
	  		echo '<td></td>';  
	  		echo '<td>Region:</td>'; 
	  		echo '<td></td>';  
	  		echo '</tr>';

	  		echo '<tr>'; 
	  		echo '<td >Classified as Grade:</td>';
	  		echo '<th>'. $result->IDNO.'</th>';  
	  		echo '<td>Section:</td>';
	  		echo '<th>' . date_format(date_create($result->BDAY),"m/d/Y").'</th>'; 
	  		echo '<td>School Year:</td>'; 
	  		echo '<th>'. $result->SEX.'</th>';   
	  		echo '<td >Name of Adviser/Teacher:</td>';
	  		echo '<th>'. $result->IDNO.'</th>';  
	  		echo '<td>Signature:</td>'; 
	  		echo '<th>'. $result->SEX.'</th>';   
	  		echo '</tr>';
  		} 
  	?>
  </tbody> 
</table>
<br/>
<table id="tables" style="width: 100%;text-align:center" class="table-bordered" >

  <thead>
  	<tr>
		<td rowspan="2">LEARNING AREAS</td>   
		<td colspan="4">Quarterly Rating</td>   
		<td rowspan="2">Final Rating</td>   
		<td rowspan="2">REMARKS</td>    
  	</tr>	
  	<tr>
		<td>1</td>   
		<td>2</td>   
		<td>3</td>   
		<td>4</td>    
  	</tr>	
  </thead> 
  <tbody>
  	<?php     
  		$sql ="SELECT * FROM `class` c, `grades` g,`subject` s WHERE c.`SUBJ_ID`=g.`SUBJ_ID` AND g.`SUBJ_ID`=s.`SUBJ_ID` AND g.`IDNO`='{$studentname}' AND c.AY = '{$ay}'";

  		$mydb->setQuery($sql);
  		$cur = $mydb->loadResultList();
// `FIRST`, `SECOND`, `THIRD`, `FOURTH`
		foreach ($cur as $result) { 
	  		echo '<tr>'; 
	  		echo '<td>'.$result->SUBJ_CODE.'</td>';
	  		echo '<td>'.$result->FIRST.'</td>';   
	  		echo '<td>'.$result->SECOND.'</td>';  
	  		echo '<td>'.$result->THIRD.'</td>';
	  		echo '<td>'.$result->FOURTH.'</td>';
	  		echo '<td>'.$result->AVE.'</td>';
	  		echo '<td>'.$result->REMARKS.'</td>'; 
	  		echo '</tr>'; 
  		} 
  	?>
  </tbody> 
  <tfoot>
  	<tr>
  		<td></td>
  		<td colspan="4">General Average</td>
  		<td><?php  ?></td>
  		<td></td> 
  	</tr>
  </tfoot>
</table>
<br/>

<br/>
<table id="table" style="width: 100%;"  > 

  	<tr>
		<th style="text-align: center;border-top: 1px solid #ddd;background-color: #ddd" colspan="10">CERTIFICATION</th>   
  	</tr>
  	<tr>
		<td>I CERTIFY that this is a true record of </td>   
		<th></th>   
		<td>with LRN</td>   
		<th></th>    
		<td>and that he/she is  eligible for admission to Grade</td>   
		<th></th>    
  	</tr>	
  	<tr>
		<td>Name of School:</td>   
		<th></th>   
		<td>School ID:</td>   
		<th></th>    
		<td>Last School Year Attended:</td>   
		<th></th>    
  	</tr>   
</table>
<br/>
<table id="table">
	 	<tr>
		<th width="30%"></th>   
		<th width="30%" colspan="3"></th>   
		<th width="30%" colspan="2"></th>      
  	</tr>  
  	<tr>
		<td align="center">Date</td>   
		<td align="center" colspan="3">Name of Principal/School Head over Printed Name</td>   
		<td align="center" colspan="2">(Affix School Seal here)</td>      
  	</tr>
</table>
 

<br/>
<br/>
 <div class="row no-print">
  <center><button type="button" class="btn btn-info pull-center" button onclick="myFunction()">Print Result</button></center>
</div>
  <script> 
  function myFunction(){
    window.print();
    
  }

  </script>  
  </section> 
	</div>
</div>