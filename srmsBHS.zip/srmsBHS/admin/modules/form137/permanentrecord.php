<style type="text/css">
  .row {
    margin-bottom: 5px;
  }
  
  @media print {
  	@page { size 8.5in 11in; margin: 0px 0px 0cm 0px; }
  body { margin: 0cm;border: 0px;} 
  	 #table tr th {
  	border-bottom: 1px solid #ddd;
  	white-space: nowrap;
  }
  }
  @media print
{    
    .no-print, .no-print *
    {
        display: none !important;
    }
}
.col-md-2{ 
}
#htable {
	width: 100%
}
#htable tr td img{
	width: 50%;
	text-align: center;
	height: 50px;
}

#htable tr td {
	text-align: center;
}
</style>
<div class="well">
						  <!-- <a href="rec.php?view=permanentrecord" class="btn btn-default"><span class="glyphicon glyphicon-circle-arrow-down"></span>  Export</a> -->
	  <!-- =============================================== -->
<form class="" method="POST" action=""> 
	<div class="row no-print mt-5 mb-5">
					 <div class="row">
					  <div class="col-sm-12 search1">
					    <label class="col-sm-12 ">Student Name:</label>
					    <div class="col-sm-12 ">
					      <div class="input-group date">
					        <div class="input-group-addon">
					          <i class="glyphicon glyphicon-user"></i>
					        </div>
					        <input required  type="text" value="<?php echo isset($_POST['studentname']) ? $_POST['studentname'] : ""; ?>" name="studentname" class="form-control pull-right date_picker "  id="studentname" placeholder="ID Number">
					      </div>
					    </div>
					  </div>
					</div>   
					 <div class="row">
					  <div class="col-sm-12 search1">
					    <label class="col-sm-12">Academic Year:</label>
					    <div class="col-sm-12"> 
					    	  <select class="form-control input-sm" name="ay" id="ay">
									<option value="2018-2019">2018-2019</option>
									<option value="2019-2020">2020-2021</option>	
									<option value="2022-2023">2022-2023</option>	
									<option value="2023-2024">2023-2024</option>	
									<option value="2024-2025">2024-2025</option>	
									<option value="2025-2026">2025-2026</option>	
									<option value="2026-2027">2026-2027</option>	
								</select>	
					    </div>
					  </div>
					</div>  
								
					<div class="row">
					  <div class="col-sm-12 search1">
					    <label class="col-sm-9"></label>
								<div class="form-group">
							         <div class="btn-group"> 
					       				<input type="submit" name="submit" class="col-sm-6 btn btn-success pull-center">
									   <a href="index.php" name="back" class="btn btn-default">Cancel </a>
									</div>
				                </div>  
					  </div>
					</div>  
				</div> 
</form>

<div class="card">
	<div class="card-body">
	<div class="row">
		<div class="col-sm-6">
			<div class="card p-2">
			<table id="htable" width="250px">
				<tr>
					<td width="20%">
						<img src="<?php echo WEB_ROOT;?>img/deped2.png">
					</td>
					<td>
							<p style="text-align: center;font-size: 12px;padding: 0px;margin: 0px;"> 
							Republic of the Philippines <br/> 
							Department of Education <br/>
							Region V <br>
							Schools Division of Sorsogon
							<h5 style="text-align: center;padding: 0px;margin: 0px;font-size:18px;"><b>BEGUIN HIGH SCHOOL</b></h5>
							Beguin Bulan Sorsogon <br>
							</p>
							
					</td>
					<td width="20%">
							<img src="logo.png">
					</td>
				</tr>
			</table>
			
			<p style="text-align: center;padding: 0px;margin: 0px;font-size:18px;"><b>JUNIOR HIGH SCHOOL DEPARTMENT</b></p>
				<hr>
			<?php     
				$studentname = isset($_POST['studentname']) ? $_POST['studentname'] : '' ;
				$ay = isset($_POST['ay']) ? $_POST['ay'] : '' ;
				$sql ="SELECT * FROM `course` c,`schoolyr` ac, `tblstudent` s WHERE  s.`IDNO`=ac.`IDNO` AND s.`IDNO`='{$studentname}' AND AY = '{$ay}'  GROUP BY s.IDNO LIMIT 1";

				$mydb->setQuery($sql);
				$cur = $mydb->loadResultList();

				foreach ($cur as $result) { 
			
			echo '<p style="font-size:12px">Name : &nbsp '. $result->FNAME.' ' . $result->LNAME.' '. $result->MNAME.'<br>
				LRN : &nbsp&nbsp '. $result->IDNO.'&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
				<span>AGE : &nbsp&nbsp '. $result->AGE.'</span>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp SEX:&nbsp&nbsp '. $result->SEX.'<br>
				GRADE : &nbsp&nbsp '. $result->COURSE_NAME.'&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<br>
				SCHOOL YEAR :  <b>'. $result->AY.'</b></p>';
			
				} 
			?>
			
			<div class="">
				<p style="font-size:12px"><b>Dear Parent, <br>
						&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
						&nbsp&nbsp&nbsp&nbsp&nbsp This report card shows the ability and progress your child
					has made in the different learning areas as well as his/her core values. <br>
					&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp The school welcomes you if you desire to know mpore about your child's progress</b>
				</p>
				<div class="d-flex col-sm-10 justify-content-end">
					<p style="border-top:1px solid black;">
						Teacher
					</p>
				</div>
				<div class="d-flex col-sm-10 justify-content-start">
					<table class="text-center ">
					<thead>
					<th>ALVIN G. GLINA JR </th>
					</thead>
					<tbody>
						<td style="border-top:1px solid black">HT-I/School Head</td>
					</tbody>
					</table>
					<!-- <p style="border-bottom:1px solid black;">ALVIN G. GLINA JR 
					</p><br class="d-flex col-sm-10 position-absolute justify-content-start">HT-I/School Head -->
				</div>
				<hr style="border:1px solid black">
				<div class="text-center">
					<h5>Certificate of Transfer</h5>
				</div>
				<p style="font-size:12px">
				Admitted to Grade:   &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp Section: <br>
				Eligible for Admission to Grade:   <br>
				Approved:   <br>
				<div class="row text-center">
					<div class="col-sm-6">
				<hr style="border:1px solid black;font-size:12px">
						School Principal
					</div>
					<div class="col-sm-6">
				<hr style="border:1px solid black;">
						<p>Teacher</p>
					</div>
				</div>
				<div class="text-center">
					<h5 class="text-center">Cancellation of Eligibility to Transfer</h5>
				</div>
				<p style="font-size:12px">Admitted in: <br>
					Date:  		
					<div class="d-flex col-sm-10 justify-content-end">
					<p style="border-top:2px solid black;font-size:12px">
						School Principal
					</p>
				</div>
				</p>

				</p>
			</div>
			</div>
		</div>
		<div class="col-sm-6">
						<div class="card">
							<div class="card-header mt-5 mb-4">
								<div class="text-center">
									<h6>REPORT ON LEARNING PROGRESS AND ACHIVEMENT</h6>
								</div>
							</div>
							<br><br>
							<table class=" table table-bordered table-striped text-center">
							<tr>
								<th rowspan="2" class="text-center"><h5>Subjects</h5></th>
								<th colspan="4"><h5>Quarterly Rating</h5></th>
								<th rowspan="2"><h5>Final Grade</h5></th>
								<th rowspan="2"><h5>Remarks</h5></th>
							</tr>
							<tr>
								<td>1st</td>
								<td>2nd</td>
								<td>3rd</td>
								<th>4th</th>
							</tr>
							<tr>
							<?php     
			// $sql ="SELECT * FROM `grades` g,`subject` s WHERE g.`SUBJ_ID`=s.`SUBJ_ID` LIMIT 1 ";
			$sql ="SELECT * FROM `class` c, `grades` g,`subject` s WHERE c.`SUBJ_ID`=g.`SUBJ_ID` AND g.`SUBJ_ID`=s.`SUBJ_ID` AND g.`IDNO`='{$studentname}' AND c.AY = '{$ay}'";
			//   $sql ="SELECT * FROM `schoolyr` ac, `tblstudent` s , `grades` g WHERE ac.`IDNO`=s.`IDNO` and s.`IDNO`=g.`IDNO` AND s.`IDNO`='{$studentname}' AND AY = '{$ay}' GROUP BY s.IDNO LIMIT 1";

			$mydb->setQuery($sql);
			$cur = $mydb->loadResultList();
			// `FIRST`, `SECOND`, `THIRD`, `FOURTH`
			foreach ($cur as $result) { 
				echo '<tr>'; 
				echo '<td>'.$result->SUBJ_CODE.'</td>';
				echo '<td>'.$result->FIRST.'</td>';   
				echo '<td>'.$result->SECOND.'</td>';  
				echo '<td>'.$result->THIRD.'</td>';
				echo '<td>'.$result->FOURTH.'</td>'; 
				echo '<td>'.$result->AVE.'</td>';
				echo '<td>'.$result->REMARKS.'</td>'; 
				echo '</tr>'; 
			} 
			?>
							</tr>
							<tr>
								<td colspan="5"><b>General Average</b></td>
								<!-- <td>99</td>
								<td>99</td>
								<td>99</td>
								<td>99</td>
								<td>99</td>
								<td><span class="badge badge-success">Passed</span></td> -->
							</tr>
							</table>
						</div>
		</div>
	<br/>
	<br/>
	<div class="row no-print">
	<center><button type="button" class="btn btn-info pull-center" button onclick="myFunction()">Print Result</button></center>
	</div>
	<script> 
	function myFunction(){
		window.print();
		
	}

  </script>  
</div>
	</div>
</div>
<style>
	p{
		font-size:12px;
	}
	h5{
		font-size:20px;
	}
</style>