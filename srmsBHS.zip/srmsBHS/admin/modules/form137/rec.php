<?php
require_once("../../../includes/initialize.php");

$view = (isset($_GET['view']) && $_GET['view'] != '') ? $_GET['view'] : '';
 $title="Inventory Report"; 
 $header=$view; 
switch ($view) {
	case 'list' :
		$content    = 'list.php';		
		break;

	case 'permanentrecord' :
		$content    = 'permanentrecord.php';		
		break;

	case 'edit' :
		$content    = 'edit.php';		
		break;
    case 'view' :
		$content    = 'view.php';		
		break;
		
		case 'form137' :
			$content    = 'form137.php';		
			break;

	default :
		$content    = 'permanentrecord.php';		
}
require_once ("../theme/templates copy.php");
?>
  
