<center>

<h1><strong>Generate Form138</strong></h1>
<a href="rec.php" name="back" class="btn btn-default">Generate </a>
</center>
<hr>
<center>

<h1><strong>Generate Form137</strong></h1>
<a href="rec.php?view=form137" name="back" class="btn btn-default">Generate </a>
</center>