<center>
<form enctype="multipart/form-data" action="controller.php?action=import" class="p-5 bg-none" method="post">
<table   class="table table-responsive shadow " align="center">
<tr >
<td colspan=2" align="center"><strong>Import CSV/Excel file</strong></td>
</tr>
<tr>
<td align="center"><b>CSV/Excel File:</b></td><td><input type="file" class="form-control" name="file" id="file"></td></tr>
<tr >
<td colspan="3" align="center"><input type="submit" name="Import" class="btn btn-dark" value="Import"></td>
</tr>
</table>
</form>

</center>